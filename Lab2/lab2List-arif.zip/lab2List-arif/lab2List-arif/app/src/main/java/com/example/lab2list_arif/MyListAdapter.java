package com.example.lab2list_talib;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class MyListAdapter extends ArrayAdapter<String> {

    Context context;
    String[] title;
    String[] subtitle;
    Integer[] imageID;

    public MyListAdapter(Context context,
                         String[] title,
                         String[] subtitle,
                         Integer[] imageID) {

        super(context, R.layout.custom_list_layout, title);

        this.context = context;
        this.title = title;
        this.subtitle = subtitle;
        this.imageID = imageID;
    }

    @NonNull
    @Override
    public View getView(int position,
                        View view,
                        @NonNull ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(context);

        @SuppressLint("ViewHolder") View row = inflater.inflate(
                R.layout.custom_list_layout,
                parent,
                false);

        TextView titleTxt = row.findViewById(R.id.title_id);
        TextView subTxt = row.findViewById(R.id.subtitle_id);
        ImageView img = row.findViewById(R.id.imag_id);

        titleTxt.setText(title[position]);
        subTxt.setText(subtitle[position]);
        img.setImageResource(imageID[position]);

        return row;
    }
}