package com.example.lab2list_talib;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    String[] title = {
            "Github App",
            "Gmail App",
            "PlayStore App",
            "Yahoo",
            "Google Drive"
    };

    String[] subTitle = {
            "Download Github App",
            "Download Gmail App",
            "Download PlayStore App",
            "Download Yahoo",
            "Download Google Drive"
    };

    Integer[] imageID = {
            R.drawable.github,
            R.drawable.gmail,
            R.drawable.play,
            R.drawable.yahoo,
            R.drawable.google
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView_id);

        MyListAdapter adapter =
                new MyListAdapter(
                        MainActivity.this,
                        title,
                        subTitle,
                        imageID);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(
                (parent, view, position, id) -> {

                    Intent intent =
                            new Intent(
                                    MainActivity.this,
                                    NewActivity.class);

                    intent.putExtra(
                            "title",
                            title[position]);

                    intent.putExtra(
                            "subTitle",
                            subTitle[position]);

                    intent.putExtra(
                            "image",
                            imageID[position]);

                    startActivity(intent);
                });
    }
}