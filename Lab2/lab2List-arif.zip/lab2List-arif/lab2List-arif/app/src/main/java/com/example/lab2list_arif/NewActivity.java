package com.example.lab2list_talib;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NewActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_new);

        TextView textView = findViewById(R.id.textView_id);
        ImageView imageView = findViewById(R.id.imag_id);

        String title = getIntent().getStringExtra("title");

        String subTitle = getIntent().getStringExtra("subTitle");

        int image = getIntent().getIntExtra("image",1);

        imageView.setImageResource(image);

        textView.setText(
                "Title: " + title +
                        "\nSubtitle: " + subTitle);
    }
}